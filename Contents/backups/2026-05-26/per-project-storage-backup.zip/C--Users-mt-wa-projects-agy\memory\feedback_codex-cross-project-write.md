---
name: Codex CLI で workdir 外に書き込む方法
description: consult-codex.sh の `ADD_DIRS` 引数 (= `codex exec --add-dir`) で別プロジェクト（Starry_hiking 等）にもリクが書き込めるようになる。Phase 2 までこれを使ってなくてティアが代筆してた問題の解決策
type: feedback
originSessionId: da1508f4-3ab4-4d2e-a660-c321e5e251f0
---
# Codex CLI の workspace-write を別プロジェクトに広げる方法

agy/ から `consult-codex.ps1` を呼ぶと workdir = agy/ になる。`workspace-write` は workdir 配下のみ書き込み可なので、**別プロジェクト（例: Starry_hiking/）には書き込めない**。Phase 2 まではこれで詰まり、ティアが代わりにコードを書く運用になっていた。

## 解決策

`codex exec --add-dir <DIR>` で writable roots に追加できる。`consult-codex.sh` を改修して第3引数 `ADD_DIRS`（カンマ区切り）を受け取り、`--add-dir` で展開する形にした（2026-04-29）。

### 呼び出し例

```powershell
.\scripts\consult-codex.ps1 `
  -Prompt "Stella の歩行アニメを実装して" `
  -Sandbox workspace-write `
  -AddDirs "C:/Users/mt_wa/projects/Starry_hiking"
```

### 確認方法

`workspace-write` + `--add-dir <path>` でリクに「writable roots を列挙して」と聞くと、追加したディレクトリが含まれていることを確認できる。

**Why:** Codex CLI のサンドボックスは workdir + 明示追加ディレクトリのみが書き込み可。`--add-dir` を渡してなかったのがラッパーの欠陥で、Codex 自体は最初から対応していた。

**How to apply:**
- 別プロジェクトでリクに実装させたいときは必ず `-AddDirs` でそのプロジェクトのフルパスを指定する
- 複数プロジェクト同時に書き込ませたいときはカンマ区切りで列挙
- `read-only` サンドボックスでは `--add-dir` を渡しても意味がない（writable root が一つもないため）
- Codex 依頼テンプレ（`.claude/templates/codex-brief.md`）の共通ヘッダーに「追加書き込みディレクトリ」項目を入れて、依頼時に明示する運用にする
