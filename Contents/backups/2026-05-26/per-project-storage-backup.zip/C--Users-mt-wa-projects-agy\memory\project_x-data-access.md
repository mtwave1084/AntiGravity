---
name: X データアクセス調査結果（2026-03-31）
description: @umbrella_bowl アカウントを使った X タイムライン取得の PoC 結果と結論
type: project
---

twscrape（vladkens/twscrape v0.17.0）による X データ取得 PoC を実施したが、2つの障壁で断念。

**Why:** X 側の Cloudflare 強化 + twscrape の内部パーサーが11ヶ月間更新されておらず、API レスポンス変化で IndexError が発生。クッキー認証を試みても全コマンドで同じエラー。

**How to apply:** X データ取得が必要になったタイミングで公式 X API（Basic プラン $200/月〜）を改めて検討する。twscrape は現時点では選択肢から外す。Playwright 等ブラウザ自動化は代替候補として残るが、未検証。

## PoC 詳細

| 試みた手段 | 結果 | 原因 |
|-----------|------|------|
| twscrape パスワード認証 | 403 Cloudflare ブロック | ボット検知 |
| twscrape クッキー認証（auth_token + ct0）| IndexError on 全コマンド | X API レスポンス構造変化・パーサー未更新 |

## 現状

- venv: `C:/Users/mt_wa/.venvs/twscrape-poc/`（残存中、削除可）
- @umbrella_bowl アカウントは X に存在、フォロー済みリスト ID: `2038916397812883900`
- bird チャネル（agent-reach）統合は未実施・保留
