---
name: ai-news 数値表記と収集漏れ防止
description: ai-news生成時の数値表現ミス（%向上≠倍率）と画像生成カテゴリの収集漏れパターン
type: feedback
originSessionId: d6282bf0-277b-409b-b0d7-2dc6ed105609
---
## 数値表記ルール：「300%向上」≠「3倍」

「300%向上」は元の値を100%として300%増加 → 合計400% = 4倍。

**Why:** 2026-04-16のai-newsで「計器読み取り成功率300%向上」を「3倍以上」と表記してソリスに指摘された。

**How to apply:** ai-news執筆時、「%向上」「%改善」の数字を倍率に変換するときは `(100 + X) / 100` 倍と計算する。「3倍以上」ではなく「約4倍」と書く。

---

## Midjourney等の画像生成ニュース収集漏れ

Midjourney V8.1 α版が4月上旬にリリースされていたが、ai-news調査で拾えなかった。

**Why:** Gemini/WebSearchの検索クエリが OpenAI/Anthropic/Google 中心で、Midjourney等の独立系画像生成ツールが抜けやすい。

**How to apply:** ai-news調査時、独立系ツール（Midjourney・Stable Diffusion・Runway・Suno・Udio等）を明示的に検索クエリに含める。特に「画像生成 Midjourney April 2026」のような専用クエリを追加する。
