---
name: Discord MCPツールの使い分け
description: plugin:discord と discord MCPの違い・ファイル添付の動作差異
type: feedback
---

## mcp__discord__reply のパラメータ名は `text`（`message` ではない）

`mcp__discord__reply` を呼ぶとき、本文は `text` パラメータで渡す。`message` を使うと `undefined is not an object (evaluating 'text.length')` エラーになる。

**Why:** server.ts の tool schema で `required: ['chat_id', 'text']` と定義されている。
**How to apply:** 必ず `text:` を使う。`message:` は間違い。

---

## mcp__discord__fetch_messages のパラメータ名は `channel`（`chat_id` ではない）

`mcp__discord__fetch_messages` を呼ぶとき、チャンネルIDは `channel` パラメータで渡す。`chat_id` を使うと `Value "undefined" is not snowflake.` エラーになる。

**Why:** server.ts の fetch_messages schema で `required: ['channel']` と定義されており、reply と違う名前になっている。
**How to apply:** `fetch_messages` は `channel:` を使う。`reply` は `chat_id:` + `text:`。ツールごとに異なるので注意。

---

## plugin:discord:discord の reply はファイル添付が動かない

`mcp__plugin_discord_discord__reply` の `files` パラメータに配列を渡すと `ENOENT: no such file or directory, stat '['` エラーになる。

**Why:** plugin:discord MCPのreplytoolがfilesパラメータの配列を正しく処理できない（`[` をパス文字列として解釈してしまう）。

**How to apply:** Discordにファイルを添付送信するときは必ず `mcp__discord__reply` を使う。`mcp__plugin_discord_discord__reply` はテキスト返信のみに使う。
