# Memory Index — AGY Project

_Last updated: 2026-04-29_

This directory stores persistent knowledge and context for the AGY project.

## Files

| File | Topic | Updated |
|------|-------|---------|
| [coding-agent-landscape.md](./coding-agent-landscape.md) | AntiGravity, Codex CLI, and the full coding agent directory map for this machine | 2026-03-24 |
| [feedback_reflection-practices.md](./feedback_reflection-practices.md) | タスク全般の振り返り改善点（構成案先出し、調査依頼の粒度、Discord返信、評価基準） | 2026-03-27 |
| [feedback_discord-tools.md](./feedback_discord-tools.md) | plugin:discord replyはファイル添付不可・mcp__discord__reply を使うこと | 2026-03-29 |
| [user_soliss.md](./user_soliss.md) | エージェント呼称ルール（ユリちゃん/リク/ティア）・ユリはソリスを「そりすん」と呼ぶ | 2026-04-01 |
| [feedback_yuri-voice.md](./feedback_yuri-voice.md) | ユリの口調ドリフト防止——一人称「あたし」・勢い系語尾・丁寧すぎるとNG | 2026-04-04 |
| [project_resource-usage.md](./project_resource-usage.md) | Claude枠4割消費（〜土曜）・Codexは余裕あり → 調査系はリクに積極委譲 | 2026-03-31 |
| [project_x-data-access.md](./project_x-data-access.md) | twscrape PoC 失敗・X データ取得は公式API待ち・bird チャネル保留 | 2026-03-31 |
| [project_mcp-startup-issue.md](./project_mcp-startup-issue.md) | start.bat初回起動時にMCP接続が失敗することがある・ターミナル再起動で解消 | 2026-04-02 |
| [project_nanobanana-pro.md](./project_nanobanana-pro.md) | Nanobanana Pro = fal-ai/gemini-3-pro-image-preview（fal.ai経由、$0.15/image〜） | 2026-04-03 |
| [project_agent-roles.md](./project_agent-roles.md) | エージェント役割確定：ティア=判断、ユリ=リサーチ+耳（音声・画像）、リク=実行 | 2026-04-03 |
| [feedback_ai-news-accuracy.md](./feedback_ai-news-accuracy.md) | ai-news: 「%向上」=倍率変換ミス防止 + Midjourney等独立系ツールの収集漏れ防止 | 2026-04-16 |
| [feedback_execution-routing.md](./feedback_execution-routing.md) | 実装系ファイル作成はリクに渡す（Godot実装でも同じ）・設計書完成後すぐ渡す | 2026-04-26 |
| [feedback_godot-tscn-japanese-comment-bug.md](./feedback_godot-tscn-japanese-comment-bug.md) | Godot 4.6: .tscn プロパティ行の日本語コメントが後続ノード読み込みを全破壊するバグ | 2026-04-26 |
| [feedback_codex-cross-project-write.md](./feedback_codex-cross-project-write.md) | consult-codex.sh の `ADD_DIRS` (= `--add-dir`) で agy/ 外（Starry_hiking 等）にもリクが書き込める | 2026-04-29 |

## Quick Reference

### Coding Agents on This Machine
- `.claude/` → Claude Code (shared with AntiGravity)
- `.agent/` → AntiGravity (VS Code fork, skills/knowledge/workflows)
- `.codex/` → Codex CLI (gpt-5.4)
- `.cursor/` → Cursor IDE
- `.gemini/` → Gemini CLI
- `.cagent/` → CAgent

### Key Fact
AntiGravity is a **VS Code fork** with Claude Code built in — not an extension.
AntiGravity Cockpit is a **separate** extension only for quota checking.
