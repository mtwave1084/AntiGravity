---
name: MCP startup connection failure — Discord plugin root cause confirmed
description: Discordプラグイン起動失敗の根本原因判明：marketplace EISDIR破損 + 0.0.1キャッシュ混入
type: project
---

## 2026-04-02: 初回報告（未解決）

初回起動（`scripts/start.bat`）でMCPサーバの接続が失敗することがある。ターミナルを一度閉じて再起動し、再度 `start.bat` を実行すると正常に接続できる。

## 2026-04-04: 根本原因判明

`claude --debug-file` のログ解析で2つのエラーを確認：

1. `EISDIR: illegal operation on a directory, read` — `~/.claude/plugins/marketplaces/claude-plugins-official/` が壊れていてファイルとして読もうとしている
2. `MCP server "discord" Server stderr: error: Script not found "start"` — プラグインが 0.0.4 ではなく不完全な 0.0.1 ディレクトリ（package.json なし）で起動しようとしている

### 確認済み正常動作
- bun v1.3.11 インストール済み ✅
- Discord ボットトークン有効（API 応答確認済み）✅
- 0.0.4 での `bun run --cwd [0.0.4 path] --shell=bun --silent start` は正常動作 ✅
- `.mcp.json` の `${CLAUDE_PLUGIN_ROOT}` が 0.0.1 に解決されているのが原因

### 修正手順（未実施・次回セッション前に実行）

```powershell
# セッションを閉じてから実行
Remove-Item -Recurse -Force "C:\Users\mt_wa\.claude\plugins\marketplaces\claude-plugins-official"
Remove-Item -Recurse -Force "C:\Users\mt_wa\.claude\plugins\cache\claude-plugins-official\discord\0.0.1"
```

次回 start.bat 起動時に marketplace が自動再クローンされ、0.0.4 のみが残って正常起動するはず。

**Why:** marketplace ディレクトリをワークスペースとして開いている状態で Claude Code の自動更新が衝突し、EISDIR 状態になった（AntiGravity の分析と一致）。
**How to apply:** 修正後に Discord ツールが正常に表示されることを確認する。再発した場合は `claude plugin install discord@claude-plugins-official` で再インストールも試す。
