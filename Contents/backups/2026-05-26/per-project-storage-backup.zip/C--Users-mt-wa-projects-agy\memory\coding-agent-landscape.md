---
name: coding-agent-landscape
description: "AntiGravity, Gemini CLI, Codex CLI などコーディングエージェントの現状と構成マップ"
metadata: 
  node_type: memory
  type: project
  originSessionId: 1bcec70f-03da-4bf4-82d1-12bf2d6db064
---

# Coding Agent Landscape — This Machine

_Last updated: 2026-05-20_

## AntiGravity

- **AntiGravity 2.0**（2026-05-19 Google I/O で発表）: VS Code ラッパーから脱却し、**スタンドアロンのエージェントファーストアプリ**に刷新された。
- 旧来の IDE は「AntiGravity IDE」名義で別途存在する（VS Code ベース）。
- 新 2.0 は CLI・SDK も同時リリース。スキル・フック・サブエージェント・エクステンション（プラグイン名義）を継承。
- **AntiGravity Cockpit** は quota チェック専用の別エクステンション（本体とは無関係）。
- `.agent/` ディレクトリは AntiGravity 管理（スキル・知識・ワークフロー）。

**Why:** 2026-05-19 Google I/O で発表。AntiGravity は Claude Code / Codex CLI と同じ「コーディングエージェントアプリ」の競合として位置づけられた。
**How to apply:** AntiGravity を「VS Code フォーク」と説明しない。「スタンドアロンのエージェント環境」として案内する。

## Gemini CLI

- **バージョン**: v0.42.0（2026-05-20 更新済み）
- **デフォルトモデル**: `gemini-3.5-flash`（2026-05-20 変更）
  - 旧: `gemini-3-flash-preview` → 新: `gemini-3.5-flash`（GA正式版）
- **認証**: `gemini-api-key`（GEMINI_API_KEY 環境変数）
- **エスカレーション先**: `gemini-3.1-pro-preview`
- ⚠️ **2026-06-18 に Gemini CLI → Antigravity CLI へ移行**
  - Gemini CLI はリクエスト停止（Pro/Ultra/無料すべて）
  - Antigravity CLI はスキル・フック・サブエージェント・エクステンションを継承予定
  - 公式 npm パッケージはまだ未公開（2026-05-20 時点）

## Coding Agent Directory Map

| Directory | Tool | Notes |
|-----------|------|-------|
| `.claude/` | Claude Code | Shared with AntiGravity's Claude Code integration |
| `.agent/` | AntiGravity | Skills / knowledge / workflows (managed by AntiGravity) |
| `.codex/` | Codex CLI | Per-project config; global config at `~/.codex/`. Model: gpt-5.4 |
| `.cursor/` | Cursor IDE | |
| `.gemini/` | Gemini CLI | v0.42.0 / デフォルトモデル: gemini-3.5-flash |
| `.cagent/` | CAgent | Mostly empty |

## Codex CLI

- Uses `~/.codex/` globally and `.codex/` per-project.
- Completely separate from `.agent/` — no overlap with AntiGravity.
- Current model: **gpt-5.4**

## Summary of Key Distinctions

- AntiGravity 2.0（スタンドアロン）≠ AntiGravity IDE（VS Code ベース）≠ AntiGravity Cockpit（quota チェック）
- `.agent/` belongs to AntiGravity; `.claude/` belongs to Claude Code
- Gemini CLI は 2026-06-18 に Antigravity CLI へ移行予定
