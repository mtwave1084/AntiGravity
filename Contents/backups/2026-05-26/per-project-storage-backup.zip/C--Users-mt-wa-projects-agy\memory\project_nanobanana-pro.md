---
name: nanobanana-pro
description: ソリスが「Nanobanana Pro」と呼ぶ画像生成エンジンの正式モデルIDと利用方法
metadata: 
  node_type: memory
  type: project
  originSessionId: 1bcec70f-03da-4bf4-82d1-12bf2d6db064
---

Nanobanana Pro = `gemini-3-pro-image-preview`

**2026-05-20 追記：** Google Pics（Google I/O 2026で発表）の内部画像生成モデルとして「Nano Banana」（Nano Banana 2 / Pro）が正式に言及された。Banana Shaker が直接呼んでいるモデルと同じもの。

**2通りのアクセス方法がある：**
1. **Banana Shaker（AGY）**: `@google/genai` SDK + Gemini API キー直接（fal.ai 不要）
2. **ユニコ .claude/ 設定**: fal.ai 経由（`fal-ai/gemini-3-pro-image-preview`、$0.15/image〜）

**Banana Shaker の nanobanana.ts（lib/nanobanana.ts）が既に実装済み：**
- `nanobanana-pro` → `gemini-3-pro-image-preview`
- `nanobanana-2` → `gemini-3.1-flash-image-preview`
- `nanobanana` → `gemini-2.5-flash-image`

**Why:** 2026-04-03 に nanobanana.ts を直接読んで確認。ユニコ調査時に「fal.ai 経由」と誤認したが、Banana Shaker は Google 直接接続。

**How to apply:**
- AGY で画像生成が必要な場合は fal.ai 不要。Banana Shaker の nanobanana.ts と同じパターン（`@google/genai` + `request.apiKey`）を流用できる
- ユリ（Gemini CLI）が使えないのは Gemini CLI のツールセット制限のため。Claude Code からは Gemini API キーで直接呼べる
